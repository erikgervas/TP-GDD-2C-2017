Grupo: 15
Curso: K3571
Integrantes: 

Ignacio Javier Fern�ndez Soto 156.009-8, 
Erik Gervas 156.208-3, 
Santiago Lucca de Guevara 156.252-6,
Nicol�s Merlis 158.100-4

Email: santiagoluccadeguevara@gmail.com