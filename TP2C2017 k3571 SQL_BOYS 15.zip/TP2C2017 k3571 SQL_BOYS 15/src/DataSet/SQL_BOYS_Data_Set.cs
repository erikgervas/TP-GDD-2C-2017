﻿namespace PagoAgil.DataSet
{
}
namespace PagoAgil.DataSet {
    
    
    public partial class SQL_BOYS_Data_Set {
    }
}
