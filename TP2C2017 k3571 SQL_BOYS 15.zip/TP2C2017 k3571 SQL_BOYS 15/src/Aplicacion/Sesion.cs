﻿using PagoAgil.Aplicacion.Modelo.ClienteSQL;
using PagoAgil.Aplicacion.Modelo.Usuario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PagoAgil.Aplicacion
{
    public class Sesion
    {

        public static Usuario usuario;

        public static SucursalDB sucursal;

    }
}
